package seleniumwebdriver.mavendemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demomaven {

	public static void main(String[] args) throws IOException {
	
			System.setProperty("webdriver.chrome.driver","C:\\Users\\91978\\Downloads\\Selenium_updatedjars\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://opensource-demo.orangehrmlive.com/");
			//to navigate to the location of excel file
			File file=new File("D:\\selenium_q&A\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(file);
			//to read the workbook
			XSSFWorkbook workbook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheetAt(0);
			Row row=sheet.getRow(1);
			Cell cell=row.getCell(0);
			String username=cell.getStringCellValue();
			Cell cell1=row.getCell(1);
			String password=cell1.getStringCellValue();
			
			driver.findElement(By.name("txtUsername")).sendKeys(username);
			driver.findElement(By.name("txtPassword")).sendKeys(password);
	}

}
